window.onload=function () {
    alert("山西");
}